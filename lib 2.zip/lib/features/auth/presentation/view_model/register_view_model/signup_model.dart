import 'package:abs_onlinestore/features/auth/data/service/auth_service.dart';
import 'package:flutter/material.dart';

class SignupModel extends ChangeNotifier {
  bool isLoading = false;
  String? error;

  Future<void> register(String name, String email, String password) async {
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      final result = await AuthService.register(name, email, password);
      print('Registration successful: $result');
    } catch (e) {
      error = e.toString();
      print('Register error: $error');
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}
